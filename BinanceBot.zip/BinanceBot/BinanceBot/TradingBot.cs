﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading;

namespace BinanceBot
{
    public class TradingBot
    {
        public static Dictionary<string, SymbolInfo> Symbols = new Dictionary<string, SymbolInfo>
        {
            { "BTCUSDT", new SymbolInfo
                { BaseAsset ="BTC", QuoteAsset="USDT", MinNotional=10m, TickSize=0.01m, StepSize=0.000001m, MinPrice=633.03m, MaxPrice=63302.7m }
            }
        };

        private readonly BinanceAPI BinanceAPI;
        private readonly string Symbol, BaseAsset, QuoteAsset, CandleInterval;
        private readonly decimal MinNotional, TickSize, StepSize, MinPrice, MaxPrice, TargetQuantity;
        private readonly int AutoTradePeriod, MovingAverage1Period, MovingAverage2Period, NumberOfCandle;
        private decimal CurrentMA1, CurrentMA2, PreviousMA1, PreviousMA2;
        //private Timer Timer;

        public TradingBot(BinanceAPI binanceAPI, int autoTradePeriod, string symbol, decimal targetQuantity, int movingAverage1Period, int movingAverage2Period, string candleInterval, int numberOfCandle)
        {
            BinanceAPI = binanceAPI;
            AutoTradePeriod = autoTradePeriod;
            Symbol = symbol;
            BaseAsset = Symbols[symbol].BaseAsset;
            QuoteAsset = Symbols[symbol].QuoteAsset;
            MinNotional = Symbols[symbol].MinNotional;
            TickSize = Symbols[symbol].TickSize;
            StepSize = Symbols[symbol].StepSize;
            MinPrice = Symbols[symbol].MinPrice;
            MaxPrice = Symbols[symbol].MaxPrice;
            TargetQuantity = targetQuantity;
            MovingAverage1Period = movingAverage1Period;
            MovingAverage2Period = movingAverage2Period;
            CandleInterval = candleInterval;
            NumberOfCandle = numberOfCandle;
        }

        public void StartAutoTrade()
        {
            Console.WriteLine("#############################################################");
            Console.WriteLine($"Start auto trade for {Symbol}");
            Console.WriteLine("#############################################################\n");
            //Timer = new Timer();
            //Timer.Interval = AutoTradePeriod * 1000;
            //Timer.Elapsed += new ElapsedEventHandler(Trade);
            //Timer.Start();

            while (true)
            {
                BotTrade();
                Thread.Sleep(AutoTradePeriod * 1000);
            }
        }

        private void BotTrade()
        {
            //Timer.Stop();
            //Get account and free balance
            var account = BinanceAPI.GetAccountInfo();
            var baseAssetbalance = account.Balances.Where(a => a.Asset == BaseAsset).FirstOrDefault(); //Only get the balance of BaseAsset
            var quoteAssetbalance = account.Balances.Where(a => a.Asset == QuoteAsset).FirstOrDefault(); //For display only
            Console.WriteLine($"================== [{DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss")}] ==================");
            Console.WriteLine("------------------------ Account ------------------------");
            Console.WriteLine($"[Free] {BaseAsset}:{baseAssetbalance.Free} {QuoteAsset}:{quoteAssetbalance.Free}");
            Console.WriteLine($"[Locked] {BaseAsset}:{baseAssetbalance.Locked} {QuoteAsset}:{quoteAssetbalance.Locked}");

            //Get open orders & candle
            var openOrders = BinanceAPI.GetOpenOrders(Symbol);
            Console.WriteLine("------------------ Current Open Orders ------------------");
            foreach (var openOrder in openOrders)
            {
                Console.WriteLine(
                    $"OrderId: {openOrder.OrderId}, " +
                    $"Side: {openOrder.Side}, " +
                    $"Type: {openOrder.Type}, " +
                    $"OrigQty: {openOrder.OrigQty}, " +
                    $"ExecutedQty: {openOrder.ExecutedQty}, " +
                    $"Price: {openOrder.Price}, " +
                    $"TimeInForce: {openOrder.TimeInForce} " 
                );
                Console.WriteLine("---------------------------------------------------------");
            }
            
            var candles = BinanceAPI.GetCandleHistory(Symbol, CandleInterval, NumberOfCandle);
            CalculateMovingAverge(candles);
            Console.WriteLine($"-------------- Compare Moving Average Lines --------------");
            Console.WriteLine($"### MA1 period: {MovingAverage1Period} | MA2 period:{MovingAverage2Period} | CandleInterval:{CandleInterval} ###");
            if (CurrentMA1 == candles[1].MoveAverage1 && CurrentMA2 == candles[1].MoveAverage2 &&
                PreviousMA1 == candles[2].MoveAverage1 && PreviousMA2 == candles[2].MoveAverage2)
            {
                Console.WriteLine("CandleList same as previous one. No action required.");
            }
            else
            {
                CurrentMA1 = Convert.ToDecimal(candles[1].MoveAverage1);
                CurrentMA2 = Convert.ToDecimal(candles[1].MoveAverage2);
                PreviousMA1 = Convert.ToDecimal(candles[2].MoveAverage1);
                PreviousMA2 = Convert.ToDecimal(candles[2].MoveAverage2);
                Console.WriteLine($"Current Candle MA1 : {CurrentMA1} MA2:{CurrentMA2}");
                Console.WriteLine($"Previous Candle MA1: {PreviousMA1} MA2:{PreviousMA2}");
                Console.WriteLine("---------------------------------------------------------");
                if ((CurrentMA1 > CurrentMA2) && (PreviousMA1 <= PreviousMA2))
                {
                    // MA1 cross above MA2 => Trend going up => New Buy & Cancel Sell                
                    Console.WriteLine("MA1 cross above MA2 => Trend going up => New Buy & Cancel Sell.");
                    BotOrder(openOrders, BinanceAPI.GetOrderBookTicker(Symbol), baseAssetbalance.Free, OrderSide.BUY);
                }
                else if ((CurrentMA1 < CurrentMA2) && (PreviousMA1 >= PreviousMA2))
                {
                    // MA1 cross below MA2 => Trend going down => New Sell & Cancel Buy
                    Console.WriteLine("MA1 cross below MA2 => Trend going down => New Sell & Cancel Buy.");
                    BotOrder(openOrders, BinanceAPI.GetOrderBookTicker(Symbol), baseAssetbalance.Free, OrderSide.SELL);
                }
                else
                {
                    // No crossover
                    Console.WriteLine("No crossover. No action required.");
                }

            }
            Console.WriteLine("============================================================\n");
            //Timer.Start();
        }

        public void BotOrder(List<Order> openOrders, OrderBookTicker orderBookTicker, decimal freeBalance, OrderSide newOrderSide)
        {
            var cancelOrderSide = newOrderSide == OrderSide.BUY ? OrderSide.SELL : OrderSide.SELL;
            var markerPrice = CalculateMakerPrice(orderBookTicker, newOrderSide);
  
            var tradeQuantity = TargetQuantity > freeBalance ? freeBalance : TargetQuantity;
            #region To be implemented
            //while (tradeQuantity * markerPrice < MinNotional)
            //{
            //    if (tradeQuantity + StepSize > freeBalance)
            //    {
            //        markerPrice += TickSize;
            //    }
            //    else
            //    {
            //        tradeQuantity += StepSize;
            //    }
            //}
            #endregion

            //Cancel 2 types of order:  [1] cancelOrderSide order   [2] newOrderSide order with price behind market, as probably not being filled
            foreach (var openOrder in openOrders.Where(a => a.Side == cancelOrderSide 
            || (a.Side == newOrderSide && newOrderSide == OrderSide.BUY ? a.Price < markerPrice : a.Price > markerPrice)))
            {
                Console.WriteLine("---------------------------------------------------------");
                Console.WriteLine($"[Cancel order] ID:{openOrder.OrderId}");
                Console.WriteLine(" ***Response:");
                Console.WriteLine(BinanceAPI.CancelOrder(Symbol, openOrder.OrderId));
            }

            //Create new order, currently only support MARKET
            Console.WriteLine($"[New order] Side:{newOrderSide}, Type:{OrderType.MARKET}, Quantity:{tradeQuantity}");
            Console.WriteLine(" ***Response:");
            Console.WriteLine(BinanceAPI.NewOrder(Symbol, newOrderSide, OrderType.MARKET, tradeQuantity));
            //Console.WriteLine($"[New order] Side:{newOrderSide}, Type:{OrderType.LIMIT}, Quantity:{tradeQuantity}, Price:{markerPrice}");
            //Console.WriteLine(BinanceAPI.NewOrder(Symbol, newOrderSide, OrderType.LIMIT, tradeQuantity, markerPrice));
        }

        private decimal CalculateMakerPrice(OrderBookTicker orderBookTicker, OrderSide side)
        {
            var buyPrice = orderBookTicker.BidPrice;
            var sellPrice = orderBookTicker.AskPrice;

            decimal orderPrice = 0;
            switch (side)
            {
                case OrderSide.BUY:
                    orderPrice = buyPrice + TickSize < sellPrice ? buyPrice + TickSize : buyPrice;
                    break;
                case OrderSide.SELL:
                    orderPrice = sellPrice - TickSize > buyPrice ? sellPrice - TickSize : sellPrice;
                    break;
            }
            return orderPrice;
        }

        private void CalculateMovingAverge(List<Candle> candles)
        {
            foreach (Candle candle in candles)
            {
                candle.PreviousCandleCount = candles.Where(a => a.CloseTime < candle.CloseTime).Count();
                if (candle.PreviousCandleCount > MovingAverage1Period)
                {
                    // Get the moving average over the last X periods using closing -- INCLUDES CURRENT CANDLE <=
                    candle.MoveAverage1 = candles.Where(a => a.CloseTime <= candle.CloseTime).OrderByDescending(a => a.CloseTime).Take(MovingAverage1Period).Average(a => a.Close);
                } // With not enough candles, we don't set to 0, we leave it null.

                if (candle.PreviousCandleCount > MovingAverage2Period)
                {
                    // Get the moving average over the last X periods using closing -- INCLUDES CURRENT CANDLE <=
                    candle.MoveAverage2 = candles.Where(a => a.CloseTime <= candle.CloseTime).OrderByDescending(a => a.CloseTime).Take(MovingAverage2Period).Average(a => a.Close);
                } // With not enough candles, we don't set to 0, we leave it null.
            }
        }

    }
}
