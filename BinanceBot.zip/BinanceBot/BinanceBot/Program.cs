﻿namespace BinanceBot
{
    class Program
    {
        private static readonly string BinacneDomain = "https://api.binance.com";
        private static readonly string BinacneKey = "T1zCLfYtY2tz9QaHHAU1QI7XXu8TqqkV1pddtRgBp13Nlj5MgB4TO17Q41jEK336";
        private static readonly string BinacneSecret = "nSjBQDhLAazRAfuAmGoZEg49C2FMYyEzMxsRniOAo6ZwHkonheTxcE2nRsOSAp5Y";

        static void Main(string[] args)
        {
            var binanceAPI = new BinanceAPI(BinacneDomain, BinacneKey, BinacneSecret);
            var tradingBot = new TradingBot(binanceAPI, 30, "BTCUSDT", 0.00001m, 3, 7, "1m", 50);
            tradingBot.StartAutoTrade();

            //Console.ReadKey();
        }


    }
}
