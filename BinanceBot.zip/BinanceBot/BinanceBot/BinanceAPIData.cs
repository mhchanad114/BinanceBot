﻿using Newtonsoft.Json;
using Newtonsoft.Json.Converters;
using System;
using System.Collections.Generic;
using System.Linq;

namespace BinanceBot
{
    public enum OrderType { MARKET, LIMIT }
    public enum OrderSide { BUY, SELL }
    public enum TimeInForce { GTC, IOC, FOK }

    public class SymbolInfo
    {
        public string BaseAsset { get; set; }
        public string QuoteAsset { get; set; } //the currency used to purchase BaseAsset
        public decimal MinNotional { get; set; } //minimum notional value allowed for an order on a symbol. An order's notional value is the price * quantity.
        public decimal TickSize { get; set; } //interval that a price/stopPrice can be increased/decreased by
        public decimal StepSize { get; set; } // intervals that a quantity/icebergQty can be increased/decreased by
        public decimal MinPrice { get; set; } //minimum price/stopPrice allowed
        public decimal MaxPrice { get; set; } //maximum price/stopPrice allowed
    }
    public class OrderBookTicker
    {
        [JsonProperty("symbol")] public string Symbol { get; set; }
        [JsonProperty("bidPrice")] public decimal BidPrice { get; set; }
        [JsonProperty("bidQty")] public decimal BidQty { get; set; }
        [JsonProperty("askPrice")] public decimal AskPrice { get; set; }
        [JsonProperty("askQty")] public decimal AskQty { get; set; }
    }
    public class Order
    {
        [JsonProperty("symbol")] public string Symbol { get; set; }
        [JsonProperty("orderId")] public long OrderId { get; set; }
        [JsonProperty("clientOrderId")] public string ClientOrderId { get; set; }
        [JsonProperty("price")] public decimal Price { get; set; }
        [JsonProperty("origQty")] public decimal OrigQty { get; set; }
        [JsonProperty("executedQty")] public decimal ExecutedQty { get; set; }
        [JsonProperty("cummulativeQuoteQty")] public decimal CummulativeQuoteQty { get; set; }
        [JsonProperty("status")] public string Status { get; set; }
        [JsonProperty("timeInForce")] public string TimeInForce { get; set; }
        [JsonProperty("type")] public string Type { get; set; }
        [JsonProperty("side")] public OrderSide Side { get; set; }
        [JsonProperty("stopPrice")] public decimal StopPrice { get; set; }
        [JsonProperty("icebergQty")] public decimal IcebergQty { get; set; }
        [JsonProperty("time")][JsonConverter(typeof(EpochConverter))] public DateTime Time { get; set; }
        [JsonProperty("updateTime")][JsonConverter(typeof(EpochConverter))] public DateTime UpdateTime { get; set; }
        [JsonProperty("isWorking")] public string IsWorking { get; set; }
    }
    public class Account
    {
        [JsonProperty("makerCommission")] public decimal MakerCommission { get; set; }
        [JsonProperty("takerCommission")] public decimal TakerCommission { get; set; }
        [JsonProperty("buyerCommission")] public decimal BuyerCommission { get; set; }
        [JsonProperty("sellerCommission")] public decimal SellerCommission { get; set; }
        [JsonProperty("canTrade")] public bool CanTrade { get; set; }
        [JsonProperty("canWithdraw")] public bool CanWithdraw { get; set; }
        [JsonProperty("canDeposit")] public bool CanDeposit { get; set; }
        [JsonProperty("updateTime")] [JsonConverter(typeof(EpochConverter))] public DateTime UpdateTime { get; set; }
        [JsonProperty("balances")] public List<Balance> Balances { get; set; }
    }
    public class Balance
    {
        public string Asset { get; set; }
        public decimal Free { get; set; }
        public decimal Locked { get; set; }
    }
    [JsonConverter(typeof(CandleConverter))]
    public class Candle
    {
        public DateTime OpenTime { get; set; }
        public decimal Open { get; set; }
        public decimal High { get; set; }
        public decimal Low { get; set; }
        public decimal Close { get; set; }
        public decimal Volume { get; set; }
        public DateTime CloseTime { get; set; }
        public decimal QuoteAssetVolume { get; set; }
        public int NumberOfTrades { get; set; }
        public decimal TakerBuyBaseAssetVolume { get; set; }
        public decimal TakerBuyQuoteAssetVolume { get; set; }
        public int PreviousCandleCount { get; set; }
        public decimal? MoveAverage1 { get; set; }
        public decimal? MoveAverage2 { get; set; }
    }
    
    public class EpochConverter : DateTimeConverterBase
    {
        public override object ReadJson(JsonReader reader, Type objectType, object existingValue, JsonSerializer serializer)
        {
            if (reader.Value == null) { return null; }
            return Common.GetDateTimeFromTimeStamp((long)reader.Value);
        }

        public override void WriteJson(JsonWriter writer, object value, JsonSerializer serializer)
        {
            throw new NotImplementedException();
        }
    }
    public class CandleConverter : JsonConverter
    {
        public override object ReadJson(JsonReader reader, Type objectType, object existingValue, JsonSerializer serializer)
        {
            var candles = Newtonsoft.Json.Linq.JArray.Load(reader);
            return new Candle
            {
                OpenTime = Common.GetDateTimeFromTimeStamp((long)candles.ElementAt(0)),
                Open = (decimal)candles.ElementAt(1),
                High = (decimal)candles.ElementAt(2),
                Low = (decimal)candles.ElementAt(3),
                Close = (decimal)candles.ElementAt(4),
                Volume = (decimal)candles.ElementAt(5),
                CloseTime = Common.GetDateTimeFromTimeStamp((long)candles.ElementAt(6)),
                QuoteAssetVolume = (decimal)candles.ElementAt(7),
                NumberOfTrades = (int)candles.ElementAt(8),
                TakerBuyBaseAssetVolume = (decimal)candles.ElementAt(9),
                TakerBuyQuoteAssetVolume = (decimal)candles.ElementAt(10)
            };
        }
        public override void WriteJson(JsonWriter writer, object value, JsonSerializer serializer)
        {
            throw new NotImplementedException();
        }
        public override bool CanConvert(Type objectType)
        {
            throw new NotImplementedException();
        }
    }
}
