﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Net;
using System.Security.Cryptography;
using System.Text;

namespace BinanceBot
{
    public class BinanceAPI
    {
        private readonly string Domain;
        private readonly string APIKey;
        private readonly string APISecret;
        private Dictionary<string, string> Parameters = new Dictionary<string, string>();
        public BinanceAPI(string domain = "", string apiKey = "", string apiSecret = "")
        {
            Domain = domain;
            APIKey = apiKey;
            APISecret = apiSecret;
        }

        #region API Functions required by TradingBot

        public OrderBookTicker GetOrderBookTicker(string symbol)
        {
            Parameters?.Clear();
            Parameters["symbol"] = symbol;
            return JsonConvert.DeserializeObject<OrderBookTicker>(Query("GET", "/api/v3/ticker/bookTicker", Parameters));
        }

        public Account GetAccountInfo()
        {
            return JsonConvert.DeserializeObject<Account>(Query("GET", "/api/v3/account", null, true));
        }

        public List<Order> GetOpenOrders(string symbol)
        {
            Parameters?.Clear();
            if (!string.IsNullOrEmpty(symbol)) Parameters.Add("symbol", symbol);
            return JsonConvert.DeserializeObject<List<Order>>(Query("GET", "/api/v3/openOrders", Parameters, true)).OrderByDescending(a => a.UpdateTime).ToList();
        }
        public List<Order> GetAllOrders(string symbol)
        {
            Parameters?.Clear();
            Parameters.Add("symbol", symbol);
            return JsonConvert.DeserializeObject<List<Order>>(Query("GET", "/api/v3/allOrders", Parameters, true)).OrderByDescending(a => a.UpdateTime).ToList();
        }

        public string NewOrder(string symbol, OrderSide side, OrderType type, decimal quantity, decimal price = 0, TimeInForce timeInForce = TimeInForce.GTC)
        {
            Parameters?.Clear();
            Parameters.Add("symbol", symbol);
            Parameters.Add("side", side.ToString());
            Parameters.Add("type", type.ToString());
            Parameters.Add("quantity", quantity.ToString());
            if (type == OrderType.LIMIT)
            {
                Parameters.Add("price", price.ToString());
                Parameters.Add("timeInForce", timeInForce.ToString());
            }
            return Query("POST", "/api/v3/order", Parameters, true);
        }

        public string CancelOrder(string symbol, long orderId)
        {
            Parameters?.Clear();
            Parameters["symbol"] = symbol;
            Parameters["orderId"] = orderId.ToString();
            return Query("DELETE", "/api/v3/order", Parameters, true);
        }

        public List<Candle> GetCandleHistory(string symbol, string interval, int limit)
        {
            Parameters?.Clear();
            Parameters["symbol"] = symbol;
            Parameters["interval"] = interval;
            Parameters["limit"] = limit.ToString();
            return JsonConvert.DeserializeObject<List<Candle>>(Query("GET", "/api/v1/klines", Parameters)).OrderByDescending(a => a.OpenTime).ToList();
        }
        #endregion

        #region Functions for having Request & Response
        private string BuildQueryData(Dictionary<string, string> param)
        {
            if (param == null)
                return "";

            StringBuilder b = new StringBuilder();
            foreach (var item in param)
                b.Append(string.Format("&{0}={1}", item.Key, WebUtility.UrlEncode(item.Value)));

            try { return b.ToString().Substring(1); }
            catch (Exception) { return ""; }
        }

        private string BuildJSON(Dictionary<string, string> param)
        {
            if (param == null) { return ""; }

            var entries = new List<string>();
            foreach (var item in param)
            {
                entries.Add($"\"{item.Key}\":\"{item.Value}\"");
            }
            return "{" + string.Join(",", entries) + "}";
        }

        private string CreateHMACSignature(string key, string totalParams)
        {
            var messageBytes = Encoding.UTF8.GetBytes(totalParams);
            var keyBytes = Encoding.UTF8.GetBytes(key);
            var hash = new HMACSHA256(keyBytes);
            var computedHash = hash.ComputeHash(messageBytes);
            return BitConverter.ToString(computedHash).Replace("-", "").ToLower();
        }

        public string Query(string method, string function, Dictionary<string, string> param = null, bool auth = false, bool json = false)
        {
            string paramData = json ? BuildJSON(param) : BuildQueryData(param);
            //string url = function + ((method == "GET" && paramData != "") ? "?" + paramData : "");
            //string postData = (method != "GET") ? paramData : "";

            string url;
            if (auth)
            {
                var argEnding = $"timestamp={DateTimeOffset.UtcNow.ToUnixTimeMilliseconds().ToString()}&recvWindow=5000";
                var adjustedSignature = !string.IsNullOrEmpty(paramData) ? $"{paramData}&{argEnding}" : $"{argEnding}";
                var hmacResult = CreateHMACSignature(APISecret, adjustedSignature);
                url = $"{function}?{adjustedSignature}&signature={hmacResult}";
            }
            else
            {
                url = $"{function}?{paramData}";
            }
            HttpWebRequest webRequest = (HttpWebRequest)WebRequest.Create(Domain + url);
            webRequest.Method = method;
            if (auth) { webRequest.Headers.Add("X-MBX-APIKEY", APIKey); }

            try
            {
                using (WebResponse webResponse = webRequest.GetResponse())
                using (Stream str = webResponse.GetResponseStream())
                using (StreamReader sr = new StreamReader(str))
                {
                    return sr.ReadToEnd();
                }
            }
            catch (WebException wex)
            {
                using (HttpWebResponse response = (HttpWebResponse)wex.Response)
                {
                    if (response == null)
                        throw;

                    using (Stream str = response.GetResponseStream())
                    {
                        using (StreamReader sr = new StreamReader(str))
                        {
                            return "Error!!!!!!!!!!!!!!!!\n" + sr.ReadToEnd();
                        }
                    }
                }
            }
        }
        #endregion
    }


}
